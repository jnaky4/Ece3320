touch newfile.txt

echo "some text" >> newfile.txt

